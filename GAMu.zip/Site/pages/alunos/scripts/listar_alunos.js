$(function(){

	$("#tab_alunos").load("scripts/listar_alunos.php");

});