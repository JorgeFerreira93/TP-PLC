$(function(){

	$("#tab_cursos").load("scripts/listar_cursos.php");

});