$(function(){

	$("#tab_professores").load("scripts/listar_professores.php");

});