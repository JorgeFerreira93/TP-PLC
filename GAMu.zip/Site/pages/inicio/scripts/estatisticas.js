$(function(){

	$("#nalunos").load("pages/inicio/scripts/nalunos.php");

	$("#nprofs").load("pages/inicio/scripts/nprofs.php");

	$("#ncursos").load("pages/inicio/scripts/ncursos.php");

	$("#naudicoes").load("pages/inicio/scripts/naudicoes.php");

	$("#top_auds").load("pages/inicio/scripts/top_auds.php");

	$("#stats").load("pages/inicio/scripts/stats.php");
});