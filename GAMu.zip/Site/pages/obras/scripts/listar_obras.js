$(function(){

	$("#tab_obras").load("scripts/listar_obras.php");

});