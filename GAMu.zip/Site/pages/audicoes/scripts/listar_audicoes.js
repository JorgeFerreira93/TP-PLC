$(function(){

	$("#tab_audicoes").load("scripts/listar_audicoes.php");

});